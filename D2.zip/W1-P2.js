/*
REGOLE
- Tutte le risposte devono essere scritte in JavaScript
- Se sei in difficoltà puoi chiedere aiuto a un Teaching Assistant
- Puoi usare Google / StackOverflow ma solo quanto ritieni di aver bisogno di qualcosa che non è stato spiegato a lezione
- Puoi testare il tuo codice in un file separato, o de-commentando un esercizio alla volta
- Per farlo puoi utilizzare il terminale Bash, quello di VSCode o quello del tuo sistema operativo (se utilizzi macOS o Linux)
*/

/* ESERCIZIO 1
 Elenca e descrivi i principali datatype in JavaScript. Prova a spiegarli come se volessi farli comprendere a un bambino.
*/
string: serie di caratteri racchiusi in apici singoli o doppi.

//let auto1 = "mazda";
//let auto2 = 'twingo';


number: numeri Float 
// let numeroIntero = 42
//  console.log(numeroIntero);

// let numeroVirgolaMobile = 3.14;
//  console.log (numeroVirgolaMobile);

// let somma = numeroIntero + numeroVirgolaMobile;
//  console.log(somma)


Boolean: rappresenta un valore vero/falso (true/false)
// let età = 18;
// if (età >= 18)
//  console.log (Benvenuto nel sito)
// else console.log (Non hai l'età per accedere a questo sito)


null: Indica che una variabile ha valore “nessun oggetto”:

undefined: Indica una variabile dichiarata ma che non ha ancora un valore assegnato;


/* SCRIVI QUI LA TUA RISPOSTA */

/* ESERCIZIO 2
 Descrivi cos'è un oggetto in JavaScript, con parole tue.
*/

Un oggetto è una raccolta di coppie chiave-valore; può rappresentare qualsiasi cosa, dalle informazioni di una persona (nome, età ecc.) ai dati di un gioco (punteggi, livelli ecc.).

 let persona = {
    nome: "Mario";
    età: "30";
    sesso: "Maschio";

}


/* SCRIVI QUI LA TUA RISPOSTA */

/* ESERCIZIO 3
 Scrivi il codice necessario ad effettuare un addizione (una somma) dei numeri 12 e 20.
*/


let numeroUno = 12; // dichiaro la prima variabile
let numeroDue = 20; // dichiaro la seconda variabile
let somma = numeroIntero + numeroVirgolaMobile; // dichiaro la terza variabile, la somma delle prime due

console.log(somma) // visualizza a schermo il numero 32

/* SCRIVI QUI LA TUA RISPOSTA */

/* ESERCIZIO 4
 Crea una variable di nome "x" e assegna ad essa il numero 12.
*/


Per creare una variblie in JavaScript ed assegnarle un valore si usa la Keyword let seguita dal nome della variabile e dal valore, preceduto dal simbolo = 

let x = 12;
console.log(x)

/* SCRIVI QUI LA TUA RISPOSTA */

/* ESERCIZIO 5
 Crea una variable chiamata "name" e assegna ad essa il tuo nome, sotto forma di stringa.
*/


let name = "Matteo"
console.log(name)


/* SCRIVI QUI LA TUA RISPOSTA */

/* ESERCIZIO 6
 Esegui una sottrazione tra i numeri 4 e la variable "x" appena dichiarata (che contiene il numero 12).
*/


let x = 12;
let y = 4;
let differenza = y - x;

console.log(differenza)

/* SCRIVI QUI LA TUA RISPOSTA */

/* ESERCIZIO 7
 Crea due variabili: "name1" e "name2". Assegna a name1 la stringa "john", e assegna a name2 la stringa "John" (con la J maiuscola!).
 Verifica che name1 sia diversa da name2 (suggerimento: è la stessa cosa di verificare che la loro uguaglianza sia falsa).
 Infine, verifica che la loro uguaglianza diventi true se entrambe vengono trasformate in lowercase (senza cambiare il valore di name2!).
 NON HAI BISOGNO DI UN BLOCCO IF/ELSE. E' sufficiente utilizzare console.log().
*/


Dichiara la variabile con let ed il nome della stessa, poi il simbolo = ed il suo valore.

let name1 = "john";
let name2 = "John";

per verificare che name1 sia diversa da name2 si usa l'operatore di disuguaglianza != 

console.log(name1 != name2); //visualiiza True

console.log(name1.toLowerCase() == name2.toLowerCase()) // metodo tool overcase, usi l'opertatore di disuguaglianza == per verificare se le stringhe sono vere o meno

_________________________________________


let num1 = 5;
let num2 = 10;

console.log(num1 != num2) // esempio numerico dell'esercizio 7.

/* SCRIVI QUI LA TUA RISPOSTA */
