window.onload = function () {
    let section = document.getElementsByClassName("display");
    section[0].classList.add("display1");
    section[1].classList.add("display2");
    section[2].classList.add("display3");
}