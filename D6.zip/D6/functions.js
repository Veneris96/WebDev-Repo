//Es 7
function modificaTitolo() {
    document.getElementsByTagName("h1")[0].innerHTML = "Questo è il vero titolo";
}

//Es 8
function changeBg() {
    document.getElementsByTagName("body")[0].style.backgroundColor= "#" + (Math.floor(Math.random() * 16777215).toString(16)); 
}    

//Es 9
function changeAdress() {
    document.getElementsByTagName("footer")[0].innerHTML = "MannaggiaAC srl, Viale Canarino 62, 31952, Colle Paglierino, VA" ;
}

//Es 10
let sfondoLink = document.getElementsByClassName("link");

function anchorBgChange() {
    
    for (let x = 0; x < sfondoLink.length; x++) { 
        sfondoLink[x].addEventListener("mouseover", function() {
        sfondoLink[x].classList.add("linkBg");
        });
        sfondoLink[x].addEventListener("mouseout", function() {
        sfondoLink[x].classList.remove("linkBg");
        });
    }   
}
anchorBgChange();

//Es 11
function removeImg() {
    let hideImage = document.getElementsByClassName("product");
    for (let i = 0; i < hideImage.length; i++) {
        hideImage[i].classList.add("hideImg");
    }
    document.getElementsByClassName("images").innerHTML="Mostra le immagini";
}

//Es 12
function colorePrezzo() {
    let prezzi = document.getElementsByClassName('prezzo');
    for (z = 0; z < prezzi.length; z++) {
        prezzi[z].style.color = "#" + (Math.floor(Math.random() * 16777215).toString(16)); 
    }
}
