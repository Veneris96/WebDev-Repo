window.addEventListener('scroll', changeBg);

function changeBg() {
    var header = document.getElementById('header');
    var scrollValue = window.scrollY;
    if(scrollValue > 450){
        header.classList.add('bgwhite');
    }
    else {
        header.classList.remove('bgwhite');
    }

    var membership = document.getElementById('membership');
    var scrollValue = window.scrollY;
    if(scrollValue > 450){
        membership.classList.add('memberyellow');
    }
    else {
        membership.classList.remove('memberyellow');
    }

    var start = document.getElementById('start');
    var scrollValue = window.scrollY;
    if(scrollValue > 450){        
        start.classList.add('startgreen');
    }
    else {
        start.classList.add('startblack');
        start.classList.remove('startgreen')
    }
}


