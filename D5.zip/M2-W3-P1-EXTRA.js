// Esercizi aggiuntivi

/* EXTRA 1
 Scrivi una funzione chiamata "checkArray", che riceve come parametro un array di numeri random (creati con giveMeRandom)
 e stampa in console, per ogni oggetto, true/false a seconda che il numero sia più grande di 5 o no.
 La funzione deve infine tornare la somma di solamente i numeri che sono risultati maggiori di 5.
*/


/* EXTRA 2
 Nel tuo sito e-commerce hai un array di oggetti chiamato shoppingCart. Ognuno di questi oggetti ha un prezzo, un nome, un id e la quantità da spedire.
 Crea una funzione chiamata "shoppingCartTotal" che calcola il totale dovuto al negozio.
*/

const shoppingCart = [
    {
     id: 321,
     name: "bluetooth headset",
     price: 100,
     quantity: 2,
    },
    {
     id: 123,
     name: "laptop",
     price: 1000,
     quantity: 1,
    },
    {
     id: 213,
     name: "USB drive",
     price: 20,
     quantity: 5,
    },
]
const shoppingCartTotal = function() {
    let totale = 0
    for (let i = 0; i < shoppingCart.length; i++) {
        totale += (shoppingCart[i].price * shoppingCart[i].quantity);
    }
    return totale
}
console.log(shoppingCartTotal);

/* EXTRA 3
 Nel tuo sito e-commerce hai un array di oggetti chiamato shoppingCart. Ognuno di questi oggetti ha un prezzo, un nome, un id e la quantità da spedire.
 Crea una funzione chiamata "addToShoppingCart" che riceve un nuovo oggetto, lo aggiunge allo shoppingCart e ritorna il numero totale degli oggetti in esso contenuti.
*/

const newShoppingCart = {
    id: 213,
    name: "USB drive",
    price: 20,
    quantity: 5,
}

const addToShoppingCart = function(addItem) {
    const newLength = shoppingCart.push(addItem);
    return newLength;
}
console.log(addToShoppingCart(newItem));
console.log(shoppingCart);



/* EXTRA 4
 Nel tuo sito e-commerce hai un array di oggetti chiamato shoppingCart. Ognuno di questi oggetti ha un prezzo, un nome, un id e la quantità da spedire.
 Crea una funzione chiamata "maxShoppingCart" che riceve l'array shoppingCart e ritorna l'oggetto più costoso in esso contenuto.
*/

const maxShoppingCart = function(cart) {
    let maxAmount = cart[0];
    for (let i = 1; i < cart; i++) {
        if (cart[i].price > maxAmount.price) {
            maxAmount = cart[i]
        }
    }
    return maxAmount;
}
console.log(maxShoppingCart(shoppingCart));

/* EXTRA 5
 Nel tuo sito e-commerce hai un array di oggetti chiamato shoppingCart. Ognuno di questi oggetti ha un prezzo, un nome, un id e la quantità da spedire.
 Crea una funzione chiamata "latestShoppingCart" che riceve l'array shoppingCart e ritorna l'ultimo oggetto in esso contenuto.
*/

const latestShoppingCart = function(cart) {
    let lastItem = cart[cart.length - 1]
    return lastItem
}
console.log(latestShoppingCart(shoppingCart));

/* EXTRA 6
 Crea una funzione chiamata "loopUntil" che riceve come parametro un intero "x" compreso tra 0 e 9.
 La funzione mostra in console un numero casuale tra 0 e 9 finchè il numero estratto è maggiore di x per 3 volte di fila.
*/

let loopUntil = function(n) {
    let counter = 0;
    while (counter !==  3) {
       let random = Math.floor(Math.random() * 10);
       console.log(random);
       if (random > n) {
        counter ++;
       } else {
        counter === 0;
       }
    }   
}
console.log(loopUntil(3));

/* EXTRA 7
 Crea una funzione chiamata "average" che riceve un array come parametro e ritorna la media aritmetica dei numeri in esso contenuti.
 La funzione salta automaticamente qualsiasi valore non numerico all'interno dell'array.
*/

function average(arr) {
    let somma = 0;
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
        if (typeof arr[i] === "number") {
            somma += arr[i];
            count++;
        }
    }
    let media = somma / count;
    return media;
}
console.log(average([7,8,9,4,"mannaggia",6,"dio",5,1]));

/* EXTRA 8
 Scrivi una funzione chiamata "longest" che ricerca la stringa più lunga all'interno del parametro ricevuto (un array di stringhe).
*/



/* EXTRA 9
 Scrivi una funzione per creare un filtro anti spam molto semplice per una casella email. La funzione riceve una stringa come parametro, "emailContent", e ritorna un boolean.
 La funzione deve tornare true se emailContent NON contiene le parole "SPAM" o "SCAM".
*/



/* EXTRA 10
 Scrivi una funzione che riceve come parametro una data e ritorna il numero di giorni passati ad oggi.
*/

const data = function(selectData) {
    let oggi = new Date () // data odierna
    let dataDiff = oggi - selectData    // diiferenxa tra data odierna e data inserita
    return Math.floor(dataDiff/(1000 * 60 * 60 * 24))   //divide la differenza per millisecondi e arrotonda
}
console.log(data(new Date("2013-01-30")));

/* EXTRA 11
 Scrivi una funzione chiamata "matrixGenerator" che riceve come parametri due interi, "x" e "y".
 La funzione deve tornare una matrice di x volte y, e ogni valore deve rappresentare l'indice dell'elemento.
 Es.: x = 3, y = 2
 ["00","01","02"
 "10","11","12"]
*/

const matrixGenerator = function(x, y) {
    let matrix = [];
    for (let i = 0; i < y; i++) {
        for (let j = 0; j < x; j++) {
            matrix.push(i.toString() + j.toString())
        }
    }
    let carPerRow = matrix.length / y;
    for (let z = 0; z < y; z++) {
        console.log(matrix.slice(z * carPerRow, (z + 1) * carPerRow))
    }
}
console.log(matrixGenerator(5 , 6));
