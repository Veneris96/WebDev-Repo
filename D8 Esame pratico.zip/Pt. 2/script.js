// memorizzo il totale dei punti in una variabile
let total = document.querySelector('#totale').innerHTML = 231;
for (let i = 0; i < questions.length; i++) {
  
}

//memorizzo la domanda alla quale l'utente sta rispondendo
let questionNumber;


//finisce la partita
if (questionNumber > domande) {
    document.write("Hai totalizzato " + total + "/" + questions.length + "punti.")
    
}
// a questo punto non so neanche più dove sbattere la testa. Questo è veramente troppo per il nostro attuale livello di preparazione.