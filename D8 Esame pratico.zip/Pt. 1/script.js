//Es 21

let x = "John ";
let y = "Doe";
console.log(x + y);

//Es 22

let person = {
    name: "Giovanni",
    surname: "Maiali",
    email: "giovamai@hotmail.com"
}

//Es 23

delete person.email
console.log(person);

//Es 24

const arr1 = ["Qui ", "devo ", "inserire ", "dieci ", "stringhe ", "all' ", "interno ", "di ", "un ", "array."];

//Es 25

console.log(arr1);

//Es 26

const arr2 = [];
while (arr2.length < 100) {
    let random = Math.floor(Math.random() * 575);
    arr2.push(random);
}
console.log(arr2);
    
//Es 27

let minValue, maxValue;

minValue = Math.min(...arr2);
maxValue = Math.max(...arr2);

console.log(minValue, maxValue);

//Es 28

const arr3 = [
    subArr1 = [],
    subArr2 = [],
    subArr3 = [],
    subArr4 = [],
    subArr5 = [],
]; 
while (subArr1.length < 10 && subArr2.length < 10 && subArr3.length < 10 && subArr4.length < 10 && subArr5.length < 10) {
    let random1 = Math.floor(Math.random() * 575);
    let random2 = Math.floor(Math.random() * 575);
    let random3 = Math.floor(Math.random() * 575);
    let random4 = Math.floor(Math.random() * 575);
    let random5 = Math.floor(Math.random() * 575);
    
    subArr1.push(random1);
    subArr2.push(random2);
    subArr3.push(random3);
    subArr4.push(random4);
    subArr5.push(random5);
    
}
console.log(arr3);

//Es 29

const arr4 = ["questo", " è", " lungo ", 745,136,5,46,8];
const arr5 = [3," questo "," invece ","meno",76,45,15,45,45,44];

function trovaIlpiùLungo() {
    if (arr4.length > arr5.length) {
        console.log("L'array più lungo è il primo: " + arr4);
    } else {
        console.log("L'array più lungo è il secondo: " + arr5)
    }
}
trovaIlpiùLungo();

//Es 30

const arr6 = [7,9,46,138,520];
const arr7 = [9,7,64,310,258];

function trovaIlMaggiore() {

let somma1 = 0;
let somma2 = 0
    for (i = 0; i < arr6.length && i < arr7.length; i++) {
        somma1 += arr6[i];
        somma2 += arr7[i];
    }
    if (somma1 > somma2) {
        console.log("L'array numerico maggiore è il primo, con un totale di: " + somma1);
        } else {
        console.log("L'array numerico maggiore è il secondo, con un totale di: " + somma2);
        }
    
}
trovaIlMaggiore();

//Es 31

document.getElementById('container');

//Es 32

document.querySelectorAll('td');

//Es 33

let testo = document.querySelectorAll('td');
    for (i = 0; i < testo.length; i++) {
        console.log(testo.innerText);
    }

//Es 34

function cambiaTitolo() {    
document.querySelector("h1").innerText = 'Brav*, hai cambiato il titolo';
}

//Es 35

function addTableRow() {
    let table = document.querySelector('#tabella');
    let tr = document.createElement('tr');
    table.appendChild(tr);
    tr.style.height = "50px";
}
addTableRow();

//Es 36

function addClass() {
    let tabella = document.querySelectorAll('tr')
    tabella.classList.add('test')
}
addClass();

//Es 37

function colorLinks() {
    let links = document.getElementsByTagName('a')
    for (let element of links) {
        element.style.backgroundColor = "red";
    }
}
colorLinks();

//Es 38

function pageLoad() {
    window.onload
    alert('Page loaded')
}
pageLoad();

//Es 39

function addToList() {
    let lista = document.querySelector('ul');
    let li = document.createElement('li');
    li.innerText = "Nuovo elemento aggiunto";
    lista.appendChild(li);
}
addToList();

//Es 40

function svuotaLista() {
   let listaOrdinata = document.getElementsByTagName('ol');
   let li = document.getElementsByTagName('li'); 
   for (i = 0; i < listaOrdinata.length; i++) {
    listaOrdinata[i].remove();
   }
}
svuotaLista();
//Riesco soltanto a rimuovere la lista in toto oppure gli elementi uno alla volta.

//Es 41



function mostraLink() {
    let link = document.querySelector('a');
    link.addEventListener('mouseover', mostraLink);
    let mouseSopra = link.onmouseover;
    if (mouseSopra === true) {
        alert('xdxdxd');
    }
}
mostraLink();
//Non riesco a farla funzionare neanche per sbaglio.

//Es 42

function nascondiImg() {
    let img = document.getElementsByTagName('img');
    for (let item of img) {
    item.style.display = "none";
    }
}
nascondiImg()

//Es 43

function nascondiTabella() {
    let tabellaNascosta = document.querySelector('table');
    tabellaNascosta.remove()
}

//Es 44

//Il contenuto delle celle della tabella non è numerico, ergo non posso effetuare una somma algebrica.

//Es 45



//Es 46


//Es 47


//Es 48


//Es 49


//Es 50

